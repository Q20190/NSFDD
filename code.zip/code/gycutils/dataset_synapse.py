import os
import random
import h5py
import numpy as np
import torch
from torchvision import transforms as T
from PIL import Image
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
import pywt

#添加cutmix



def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k, axes=(-2, -1))
    label = np.rot90(label, k)
    axis = np.random.randint(1, 3)
    image = np.flip(image, axis=axis-1).copy()
    label = np.flip(label, axis=axis-1).copy()
    return image, label


def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, axes=(-2, -1),order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

class RandomGenerator(object):
    def __init__(self, output_size,split):
        self.output_size = output_size
        self.split=split

    def __call__(self, sample):
        image, label ,filename= sample['image'], sample['label'],sample['name']

        if self.split=='train':
            if random.random()>0.5:
                image,label=random_rot_flip(image,label)
            elif random.random()>0.5:
                image,label=random_rotate(image,label)

        x, y= image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)  # 图像插值使用双线性插值
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)  # 标签插值使用最邻近插值
        image = torch.from_numpy(image.astype(np.float32))
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long(), 'name':filename}
        return sample

class Synapse_dataset(Dataset):
    def __init__(self, base_dir,split, transform=None):
        self.transform = transform
        self.split = split
        self.DNB_list = list(map(lambda x:os.path.join(base_dir,self.split,'DNB',x),os.listdir(os.path.join(base_dir,self.split,'DNB'))))
        self.data_dir = base_dir
        self.GT_path=os.path.join(base_dir,self.split,'LABEL')
        print("image count in {} path :{}".format(self.split,len(self.DNB_list)))

    def __len__(self):
        return len(self.DNB_list)

    def __getitem__(self, idx):
        DNB_dir = self.DNB_list[idx]
        filename=DNB_dir.split('/')[-1]
        mask_dir=os.path.join(self.GT_path,filename)


        DNB=Image.open(DNB_dir).convert('L')
        mask=Image.open(mask_dir).convert('L')


        DNB=np.asarray(DNB)
        img=DNB
        mask=np.asarray(mask)


        if len(mask.shape)==3:
            mask=mask[:,:,0]

        mask=mask.copy()
        mask[mask>0]=1

        image, label = img, mask
        sample = {'image': image, 'label': label, 'name':filename}
        if self.transform: # 用于做图像增强，实际使用RandomGenerator函数进行
            sample = self.transform(sample)
        return sample
