import torch
from torch.autograd import Variable,grad
def make_trainable(model, val):
    for p in model.parameters():
        p.requires_grad = val


def calc_gradient_penalty(netD, real_data, fake_data,LAMBDA=10):
    BATCH=real_data.size()[0]
    alpha = torch.rand(BATCH, 1)
    #print(alpha.size(),real_data.size())
    alpha = alpha.unsqueeze(-1).unsqueeze(-1).expand(real_data.size())
    alpha = alpha.cuda()
    interpolates = alpha * real_data + ((1 - alpha) * fake_data)
    interpolates = interpolates.cuda()
    interpolates = Variable(interpolates, requires_grad=True)

    disc_interpolates = netD(interpolates)

    gradients = grad(outputs=disc_interpolates, inputs=interpolates,
                              grad_outputs=torch.ones(disc_interpolates.size()).cuda(),
                              create_graph=True, retain_graph=True, only_inputs=True)[0]

    gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean() * LAMBDA
    return gradient_penalty


def calculate_metric_percase(SR, GT):
    # thread=0.5
    # SR[SR >thread] = 1
    # SR[SR<=thread]=0
    # GT[GT > thread] = 1
    # GT[GT<=thread]=0

    corr=torch.sum(SR==GT)
    tensor_size=GT.shape[0]*GT.shape[1]
    acc=float(corr)/float(tensor_size+1e-6)
    if acc>1:
        acc=0
    TP=torch.sum((GT==1)&(SR==1))
    FN=torch.sum((GT==1)&(SR==0))
    TN=torch.sum((SR==0)&(GT==0))
    FP=torch.sum((SR==1)&(GT==0))
    Inter=torch.sum((SR==1)&(GT==1))
    Union=torch.sum(((SR==1)&(GT==0))|((SR==0)&(GT==1)))


    recall=float(TP)/(float(TP+FN)+1e-6)
    precision=float(torch.sum(TP))/(float(torch.sum(TP+FP))+1e-6)
    pod=float(torch.sum(TP))/(float(torch.sum(TP+FN))+1e-6)
    far=float(torch.sum(FP))/(float(torch.sum(TN+FP))+1e-6)
    csi=float(torch.sum(TP))/(float(torch.sum(TP+FP+FN))+1e-6)
    mar=float(torch.sum(FN))/(float(torch.sum(TP+FN))+1e-6)
    F1=2*recall*precision/(recall+precision+1e-6)
    JS=float(Inter)/(float(Union)+1e-6)
    DC=float(2*Inter)/(float(torch.sum(SR==1)+torch.sum(GT==1))+1e-6)
    # iou=TP/(TP+FP+FN)
    backiou=TN/(TN+FP+FN)
    miou=(csi+backiou)/2

    return [recall,pod,far,precision,csi,mar,F1,JS,DC,miou]